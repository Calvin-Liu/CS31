//
//  main.cpp
//  googoo
//
//  Created by Calvin Liu on 11/11/12.
//  Copyright (c) 2012 Calvin Liu. All rights reserved.
//

#include <iostream>
#include <cassert>
#include <cstring>
#include <cctype>
#include <string.h>
using namespace std;

const int MAX_WORD_LENGTH = 20;

void shiftingelements();
void shiftingnumbers();

void shiftingelements(int start, char aWord[][MAX_WORD_LENGTH+1], int nCriteria)
{
    for(int m = start; m < nCriteria; m++)
        strcpy(aWord[m], aWord[m+1]);
}
void shiftingnumbers(int start, int aNumber[], int nCriteria)
{
    for(int m = start; m < nCriteria; m++)
        aNumber[m] = aNumber[m+1];
}


int normalizeCriteria(int distance[],
                      char word1[][MAX_WORD_LENGTH+1],
                      char word2[][MAX_WORD_LENGTH+1],
                      int nCriteria)
{
    int j;
    int numElementsInArr = nCriteria;
    for (j = 0; j != numElementsInArr; j++)
    {
        for (int k = 0; k != strlen(word1[j]); k++)
        {
            if (isupper(word1[j][k]))           //if it is uppercase, make it lowercase
                word1[j][k] = tolower(word1[j][k]);
        }
        for (int k = 0; k != strlen(word2[j]); k++)
        {
            if (isupper(word2[j][k]))
                word2[j][k] = tolower(word2[j][k]);
        }
        
        bool b = false;
        
        for (int k = 0; k < strlen(word1[j]); k++)
        {
            if(!islower(word1[j][k])) //if the word has something that is not a letter
            {
                b = true;
            }
        }
        
        for (int k = 0; k < strlen(word2[j]); k++)
        {
            if(!islower(word2[j][k])) //if the word has something that is not a letter
            {
                b = true;
            }
        }
        
       if (distance[j] <= 0 || word1[j][0] == '\0' || word2[j][0] == '\0' || b)
       {
           shiftingelements(j, word1, numElementsInArr);
           shiftingelements(j, word2, numElementsInArr);
           shiftingnumbers(j, distance, numElementsInArr);
           numElementsInArr--;
           j--;
       }
        
        for (int m = j+1; m < numElementsInArr; m++)
        {
            if (strcmp(word1[j],word1[m]) == 0)
            {
                if(distance[j] < distance[m])
                {
                    shiftingelements(j, word1, numElementsInArr);
                    shiftingelements(j, word2, numElementsInArr);
                    shiftingnumbers(j, distance, numElementsInArr);
                    numElementsInArr--;
                    j--;
                }
                else
                {
                    shiftingelements(m, word1, numElementsInArr);
                    shiftingelements(m, word2, numElementsInArr);
                    shiftingnumbers(m, distance, numElementsInArr);
                    numElementsInArr--;
                    j--;
                }
            }
        }
    }
    return numElementsInArr;
}

/*
int main()
{
    const int TEST1_NCRITERIA = 4;
    int test1dist[TEST1_NCRITERIA] = {
        2,           4,          1,           13
    };
    char test1w1[TEST1_NCRITERIA][MAX_WORD_LENGTH+1] = {
        "mad",       "deranged", "nefarious", "have"
    };
    char test1w2[TEST1_NCRITERIA][MAX_WORD_LENGTH+1] = {
        "scientist", "123",    "plot",      "mad"
    };
 
    int n = normalizeCriteria(test1dist, test1w1, test1w2, TEST1_NCRITERIA);
    cout << n << endl;
    for (int k = 0; k < n; k++)
    {
        cout << test1dist[k] << "   " << test1w1[k] << "   " << test1w2[k] << endl;
    }
        
}
*/    

//now everything is correct and can't be wrong


void rotateleft();

void rotateleft(int startRotation, char localarr[], const char document[])
{
    for (int n = startRotation; n < strlen(document); n++)
    {
        localarr[n] = localarr[n+1];
    }
    
}

int computeScore(const int distance[],
                 const char word1[][MAX_WORD_LENGTH+1],
                 const char word2[][MAX_WORD_LENGTH+1],
                 int nCriteria,
                 const char document[])
{
   
    int score = 0;
    char localarr[201];
    char localarr2[101][201];
    strcpy(localarr,document); //make a copy of the document because you can't modify the document

    for (int k = 0; k < strlen(localarr); k++)
    {
        if (isupper(localarr[k]))          //fix the document
            localarr[k] = tolower(localarr[k]);
        if (!islower(localarr[k]) && localarr[k] != ' ')
        {
            rotateleft(k, localarr, document);
            k--;
        }
    }
    
    
    int j = 0;
    int i;
    for (int k = 0; k < strlen(localarr); k++)  //converting the document to a 2D array
    {
       if (localarr[k] != ' ')
       {
           localarr2[j][i] = localarr[k];
           i++;
       }
       else
       {
            localarr2[j][i] = '\0';
            j++;
            i = 0;
       }
    }
    
    
    localarr2[j][i] = '\0';
    bool found[nCriteria];
    for(int i=0; i < nCriteria; i++)
    {
        found[i] = false;
    }
    
    for (int x = 0; x < nCriteria; x++)
    {
        for (int k = 0; k < j; k++)       
        {
            
            if (strcmp(word1[x], localarr2[k]) == 0)
            {
                int place = distance[x];
                int m = 0;
                for (m = k; m <= (k+place); m++)
                {
                    if (strcmp(word2[x], localarr2[m]) == 0 && !found[x])
                    {
                        score++;
                        found[x] = true;
                    }
                }
            }
        }
    }
    return score;
}







#include <iostream>
#include <cassert>
using namespace std;
int main()
{
    const int TEST1_NCRITERIA = 4;
    int test1dist[TEST1_NCRITERIA] = {
        2,           4,          1,           13
    };
    char test1w1[TEST1_NCRITERIA][MAX_WORD_LENGTH+1] = {
        "mad",       "deranged", "nefarious", "have"
    };
    char test1w2[TEST1_NCRITERIA][MAX_WORD_LENGTH+1] = {
        "scientist", "robot",    "plot",      "mad"
    };
    
   
    assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
                        "The mad UCLA scientist unleashed a deranged evil giant robot.") == 2);
    assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
                        "The mad UCLA scientist unleashed    a deranged robot.") == 2);
    assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
                        "**** 2012 ****") == 0);
    assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
                        "  What a NEFARIOUS plot!") == 1);
    assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
                        "deranged deranged robot deranged robot robot") == 1);
    assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
                        "Two mad scientists have deranged-robot fever.") == 0);
    assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
                        "                                        ") == 0);
    assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
                        "mad mad mad goal is the best scientist") == 0);
    assert(computeScore(test1dist, test1w1, test1w2, TEST1_NCRITERIA,
                        "blah blah blah, deranged robot") == 1);

    cout << "All tests succeeded" << endl;
}